# fr / findref


![Version](https://img.shields.io/badge/Version-v1.6.1-green)

`findref` (commonly aliased to `fr`) helps you find strings, or match regular expressions, in a directory of files.  It is inspired by `git grep` which is a good tool, but has limitations that made writing a replacement a worthy endeavor.

`findref` regular expressions are golang regexes.  Golang regexes have "the [same general
syntax](https://github.com/google/re2/wiki/Syntax) used by Perl, Python, and other languages.
More precisely, it is [the syntax accepted by RE2](https://github.com/google/re2/wiki/Syntax)."
A large benefit of this, is that "the regexp implementation ... [is guaranteed to run in
time linear in the size of the input](https://swtch.com/~rsc/regexp/regexp1.html).
(This is a property not guaranteed by most open source implementations of regular expressions.)" (see: https://golang.org/pkg/regexp/).  This regex run-time is one of the things that makes
`findref` faster than many other tools.


## How it compares to other tools (or why it is better in my opinion):

**grep**:  `findref` adds much simpler recursive search that doesn't require a bunch of
tedious flags to get pleasant output.  It also ignores hidden files by default,
which helps you avoid a lot of junk matches.  findref has a lot of handy command line
switches that make it easier to find the needle in the haystack.  For example, the ability
to restrict search to files whose name matches a specified regex.  The output of `findref` is
identical to grep's line numbers and colors (but are on by default).  Speed-wise, grep
is faster.  It's hard to beat this venerable tool in performance.

**git grep**:  `findref` output looks very similar, but adds colorization, which makes
reading it *much* easier.  `findref` also works on non-git repos, unlike git grep.  findref
also supports a variety of switches that make narrowing results easier.

**Ag (or the silver searcher)**:  `findref` is slower (ag is amazingly fast), but has
much better formatting and coloring.  `findref` does not currently have a vim
plugin tho, so for searching within vim, [ag](https://github.com/vim-scripts/ag.vim)
is the way to go.  Ag is also useful for very large codebases.


## Usage

<p align="center">
  <img src="images/findref-usage.png" alt="findref usage">
</p>

### Default exclusions

Even without passing any `--exclude` flags, `findref` prunes directories and lockfiles that usually contain generated artifacts or vendored dependencies: `.git`, `.svn`, `.hg`, `.bzr`, `CVS`, `vendor`, `node_modules`, `build`, `dist`, `out`, `coverage`, `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `bun.lockb`, `composer.lock`, `Gemfile.lock`, `mix.lock`, `Cargo.lock`, `Pipfile.lock`, `poetry.lock`, `Podfile.lock`, `go.sum`, and `gradle.lockfile`. Use additional `--exclude` values—these can be directories or single files—to extend this list. Values are plain strings, not regexes or globs. A bare name like `tmp` matches any file or directory with that basename at any depth. A value containing a path separator like `src/generated` matches paths ending in that suffix. For more advanced filtering, use `--exclude-pattern` with an RE2 regex. The pattern is tested against the full cleaned relative path, so `--exclude-pattern '_test\.go$'` skips all Go test files and `--exclude-pattern '(^|/)generated($|/)'` skips any directory named `generated`. Multiple `--exclude-pattern` flags can be stacked and are combinable with `--exclude`. Hidden files and directories remain ignored unless you supply `--hidden` or `--all`, but the entries above stay excluded to keep searches fast. Need to crawl everything? Pass `--all` (which already implies hidden files and ignore-case) to disable the defaults, then layer on whichever `--exclude` values still make sense for that search.

### Configuration file

`findref` can read defaults from a YAML config file. It checks for one in this order and stops at the first match:

1. `./.findref.yaml`
2. `$XDG_CONFIG_HOME/findref/config.yaml` (falls back to `~/.config/findref/config.yaml`)
3. `~/.findref.yaml`

If no file is present, behavior stays the same. When a file is found, the values are applied as if they were flags; anything you put on the command line still wins. The YAML keys mirror the long flag names: `all`, `debug`, `stats`, `hidden`, `version`, `no_color`, `match_case`, `ignore_case`, `filename_only`, `max_line_length`, `no_max_line_length`, `exclude` (list), `exclude_pattern` (list), and the positional arguments `match_regex`, `start_dir`, `filename_regex`.

Example:

```yaml
match_regex: todo
start_dir: .
ignore_case: true
filename_only: true
exclude:
  - vendor
  - .git
```

Generate a starter config with comments using `findref --write-config` (defaults to `local`, writing `./.findref.yaml`) or pass `global` to write to `$XDG_CONFIG_HOME/findref/config.yaml` (fallback `~/.findref.yaml`). Existing files are left untouched to avoid accidental overwrites.

### MCP server (AI agent integration)

`findref` can run as an [MCP (Model Context Protocol)](https://modelcontextprotocol.io/) server, letting AI coding assistants such as Claude Code, Cursor, and Windsurf use it as a tool. No daemon or background process is required — the AI tool launches `findref --mcp` as a subprocess and communicates over stdin/stdout using JSON-RPC.

To register findref as an MCP server, add it to your AI tool's MCP configuration:

```json
{
  "mcpServers": {
    "findref": {
      "command": "findref",
      "args": ["--mcp"]
    }
  }
}
```

The server exposes two tools:

| Tool | Description |
|------|-------------|
| `search` | Search for text patterns using all of findref's features (pattern, directory, file filter, excludes, case control, filename-only mode, etc.). Returns structured JSON with file path, line number, matched text, and match offsets. |
| `list_default_excludes` | Returns the list of directories and files excluded by default, so the agent can understand what is being filtered. |

Example interaction (the AI tool handles this automatically):

```json
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"search","arguments":{"pattern":"^func.*Handler","file_pattern":"\\.go$","exclude":["vendor"]}}}
```

Response:

```json
{"matches":[{"file":"server.go","line":42,"text":"func NewHandler(cfg Config) http.Handler {","match_start":0,"match_end":18}],"total_files_scanned":15,"total_lines_scanned":1200,"total_matches":1}
```

### Examples:

Let's say we are looking for the string "getMethodName":

Simple usage that starts looking recursively in the current directory, and checks all files (excluding binary files) for the string (which could also be a regular expression)

    findref getMethodName

<p align="center">
  <img src="images/findref-simple.gif" alt="findref simple usage">
</p>

To go case insensitive, simply add -i or --ignore-case as the first arg:

    findref --ignore-case getMethodName

By default `findref` uses "smart-case" for matches.  This means if the whole regex is lower
case, the match will be case-insensitve.  If there is an upper case letter, the match will be
case-sensiitive.  You can force case-sensitivity with the -m or --match-case flag:

    findref --match-case getmethodname  # matches getmethodname but not getMethodName

You don't have to search only for strings.  You can pass any valid golang regex:

    findref "str[i1]ng.*"
    findref "st.*ng"

<p align="center">
  <img src="images/findref-regex.gif" alt="findref regex usage">
</p>

You can add a starting directory (if none is specified, the default is the current working directory):

    findref "str[i1]ng.*" /home/ben/my-starting-directory

<p align="center">
  <img src="images/findref-starting-loc.gif" alt="findref starting location usage">
</p>

If you want to restrict which files are searched, you can also do this by passing a file
matching regex.  For example, to only search cpp files:

    findref "str[i1]ng.*" "~/my-starting-directory" ".*.cpp"

Or to restrict the search to C++ code files (.h and .cpp):

    findref "str[i1]ng.*" "~/my-starting-directory" ".*\.[hc](pp)?"

<p align="center">
  <img src="images/findref-file-regex.gif" alt="findref file regex usage">
</p>

## Installation

### Use the install script

If you are on an intel-based linux or mac, there is an install script located at
`install.sh`.  If on ARM, Windows, or {Free,Open}BSD, you should download the
appropriate [pre-built binary](#pre-built-binaries) below.

To let the script do the work, run this command.  Make sure to add `sudo` if
installing to a location that isn't writeable by your normal user:

#### In your home directory (Make sure this destination is in your [PATH](http://www.linfo.org/path_env_var.html) variable)

```bash
curl -s https://raw.githubusercontent.com/FreedomBen/findref/master/install.sh | bash -s $HOME/bin
```

#### System-wide for all users (requires root access)
```bash
curl -s https://raw.githubusercontent.com/FreedomBen/findref/master/install.sh | sudo bash -s /usr/local/bin
```

### Shell autocomplete

`findref` ships with completion helpers for Bash, Zsh, and Fish. They suggest flags, help fill in exclude directories, and offer quick-start regex snippets for the positional arguments, so you can explore the CLI without memorizing every switch.

#### Bash

1. Source it for your current shell (replace the path with wherever you cloned the repo):
   ```bash
   source /path/to/findref/contrib/completions/findref.bash
   ```
2. To load the completion automatically, either copy or symlink the script into a directory that Bash Completion reads (for example `/etc/bash_completion.d/findref`), or add the `source` command above to your `~/.bashrc`.

#### Zsh

1. Load completions for the current session:
   ```zsh
   source /path/to/findref/contrib/completions/findref.zsh
   ```
2. For automatic loading, copy or symlink the script into a directory that appears in your `$fpath` (for example `/usr/local/share/zsh/site-functions/_findref`) or `source` it from your `~/.zshrc` after `compinit`.

#### Fish

1. Test it in the current shell:
   ```fish
   source /path/to/findref/contrib/completions/findref.fish
   ```
2. For permanent availability, copy or symlink the file to `~/.config/fish/completions/findref.fish` (or another directory listed in `fish_complete_path`).

### Pre-built binaries

If you wish, you can download pre-built binaries for your system.  After downloading,
put it somewhere in your [PATH](http://www.linfo.org/path_env_var.html).

I recommend putting it in `~/bin` if you are the only user (`sudo` isn't required
to install in that location), or `/usr/local/bin` if there are multiple users on the system:

#### Current Release Version: 1.6.1

These links will always point to the latest released version, so they are includable in
scripts to get the latest version without having to adjust the version number for new
releases.  Of course if you want to point to a specific release, find the permanent link
on the [ARCHIVES.md](ARCHIVES.md) page.

| Version | Linux | macOS | Windows | FreeBSD | OpenBSD |
|:-------:|:-----:|:-----:|:-------:|:-------:|:--------|
| latest | [386](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/386/findref.zip) - [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/amd64/findref.zip) - [arm](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/arm/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/arm64/findref.zip) | [386](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/darwin/386/findref.zip) - [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/darwin/amd64/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/darwin/arm64/findref.zip) | [386](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/windows/386/findref.zip) - [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/windows/amd64/findref.zip) | [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/freebsd/amd64/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/freebsd/arm64/findref.zip) | [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/openbsd/amd64/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/openbsd/arm64/findref.zip) |

These links are perma-links to the binaries for version 1.6.1, meaning even after
a new version is released, these will still get you version 1.6.1.

| Version | Linux | macOS | Windows | FreeBSD | OpenBSD |
|:-------:|:-----:|:-----:|:-------:|:-------:|:--------|
| 1.6.1 | [386](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/linux/386/findref.zip) - [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/linux/amd64/findref.zip) - [arm](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/linux/arm/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/linux/arm64/findref.zip) | [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/darwin/amd64/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/darwin/arm64/findref.zip) | [386](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/windows/386/findref.zip) - [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/windows/amd64/findref.zip) | [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/freebsd/amd64/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/freebsd/arm64/findref.zip) | [amd64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/openbsd/amd64/findref.zip) - [arm64](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/1.6.1/openbsd/arm64/findref.zip) |

### Linux packages

If you prefer native packages over the raw zip archives, every Linux build now ships Debian (`.deb`), RPM (`.rpm`), Alpine (`.apk`), and Arch Linux (`.pkg.tar.zst`, amd64 only) artifacts inside the same `findref-bin/<release>/linux/<arch>/` directories referenced above.

**Current release downloads (amd64)**

- [Debian / Ubuntu (.deb)](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/amd64/findref_1.6.1_amd64.deb)
- [Fedora / RHEL / openSUSE (.rpm)](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/amd64/findref-1.6.1-1.x86_64.rpm)
- [Alpine (.apk)](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/amd64/findref-1.6.1.x86_64.apk)
- [Arch Linux (.pkg.tar.zst)](https://raw.githubusercontent.com/FreedomBen/findref-bin/master/latest/linux/amd64/findref-1.6.1-1-x86_64.pkg.tar.zst)

Swap `amd64` in the URL for `386`, `arm`, or `arm64` to grab the other architectures (the Arch package is amd64-only). The Debian packages use `amd64`, `arm64`, `armhf`, `i386` suffixes; RPM uses `x86_64`, `aarch64`, `armv7hl`, `i386`; APK uses `x86_64`, `aarch64`, `armhf`, `x86`. Replace `latest` with a concrete version (see [ARCHIVES.md](ARCHIVES.md)) if you need to pin to a specific release.

### Older releases

The full catalog of releases is available to download.  See [ARCHIVES.md](ARCHIVES.md)

### Building from source

To build from source you can either use the docker build wrapper, or build it directly on your system.

If you have your [Go environment](https://golang.org/doc/install) set up
already, you can build it directly from source:

```bash
go get github.com/FreedomBen/findref
go install findref
```

To use the docker build, the easiest way is to clone this repo and use the rake task:

```bash
git clone https://github.com/FreedomBen/findref.git \
 && cd findref \
 && rake
```

Pretty easy, the only downside being that it will build findref for every supported
platform rather than just the one you care about.  You can find the binary you
care about by looking in the `findref-bin` subdirectory and following the directory
structure until you find the correct binary for your system.

You can also build for just
your platform.  Specify your OS for the `GOOS` value, and your arch for `GOARCH`.
See [here for a list of valid targets](https://stackoverflow.com/a/30068222/2062384).

Clone the repo if you haven't already:

```bash
git clone https://github.com/FreedomBen/findref.git && cd findref
```

Then run the build:

Example for Linux x64 (amd64):

```bash
docker run \
  --rm \
  --volume "$(pwd):/usr/src/findref" \
  --workdir "/usr/src/findref" \
  --env GOOS=linux \
  --env GOARCH=amd64 \
  golang:#{GO_VERSION} go build
```

Example for Linux x32 (386):

```bash
docker run \
  --rm \
  --volume "$(pwd):/usr/src/findref" \
  --workdir "/usr/src/findref" \
  --env GOOS=linux \
  --env GOARCH=386 \
  golang:#{GO_VERSION} go build
```

Example for macOS x64 (amd64)

```bash
docker run \
  --rm \
  --volume "$(pwd):/usr/src/findref" \
  --workdir "/usr/src/findref" \
  --env GOOS=darwin \
  --env GOARCH=amd64 \
  golang:#{GO_VERSION} go build
```

After the build your binary should be sitting in the root directory of the repo!
